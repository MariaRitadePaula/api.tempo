import requests

latitude = -19.92
longitude = -43.94

url = f"https://api.open-meteo.com/v1/forecast?latitude={latitude}&longitude={longitude}&current_weather=true"

try:
    resposta = requests.get(url)
    resposta.raise_for_status()  
    dados = resposta.json()
except requests.RequestException as e:
    print("Erro ao consultar a API:", e)

clima_atual = dados["current_weather"]
temperatura = clima_atual["temperature"]
vento = clima_atual["windspeed"]
direcao_vento = clima_atual["winddirection"]
codigo_clima = clima_atual["weathercode"]

def emoji_por_temperatura(temp):
    """
    Retorna um emoji baseado na temperatura (°C)
    """
    if temp >= 30:
        return "☀️"  
    elif 20 <= temp < 30:
        return "🌤️"  
    elif 10 <= temp < 20:
        return "☁️"  
    elif 0 <= temp < 10:
        return "🌧️"  
    else:  
        return "❄️"  

# ---- Chamando a função e mostrando no terminal ----
emoji_temp = emoji_por_temperatura(temperatura)

print(f"Temperatura atual: {temperatura}°C {emoji_temp}")
print(f"Velocidade do vento: {vento} km/h")
print(f"Direção do vento: {direcao_vento}°")
print(f"Código do clima: {codigo_clima}")